#!/bin/bash

mvn install:install-file -Dfile=./miniapplet-full.jar -DgroupId=es.gob.afirma -DartifactId=afirma-miniapplet-full -Dversion=1.2  -Dpackaging=jar
